package student;

import database.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Marks {

    Connection con = MyConnection.getConnection();
    PreparedStatement ps;

    public boolean getid(int id, int semesterno) {
        try {
            ps = con.prepareStatement("select * from course where student_id=? and semester=?");
            ps.setInt(1, id);
            ps.setInt(2, semesterno);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Main_Menu.jTextField33.setText(String.valueOf(rs.getString(1)));
                Main_Menu.jTextField8.setText(rs.getString(2));
                Main_Menu.jTextField38.setText(rs.getString(3));
                Main_Menu.jTextcourse1.setText(rs.getString(4));
                Main_Menu.jTextcourse2.setText(rs.getString(5));
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Student ID or Semester Doesn't Exist");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Marks.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean isSemesterNoExist(int id, int semesterno) {
        try {
            ps = con.prepareStatement("select * from marks where student_id=? and semester=?");
            ps.setInt(1, id);
            ps.setInt(2, semesterno);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Marks.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void insert(int id, String name, int semester, String course1, String course2, double mark1, double mark2, double gpa1, double gpa2, double sgpa) {
        String sql = "insert into marks values(?,?,?,?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setInt(3, semester);
            ps.setString(4, course1);
            ps.setDouble(5, mark1);
            ps.setDouble(6, gpa1);
            ps.setString(7, course2);
            ps.setDouble(8, mark2);
            ps.setDouble(9, gpa2);
            ps.setDouble(10, sgpa);
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student's Marks Added Successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Marks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getMarksValue(JTable table, String searchValue) {
        String sql = "select * from marks where concat(student_id,name,semester)like ? order by student_id asc, semester asc";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[10];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getInt(3);
                row[3] = rs.getString(4);
                row[4] = rs.getDouble(5);
                row[5] = rs.getDouble(6);
                row[6] = rs.getString(7);
                row[7] = rs.getDouble(8);
                row[8] = rs.getDouble(9);
                row[9] = rs.getDouble(10);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Marks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void delete(int id, int semester) {
        int ok = JOptionPane.showConfirmDialog(null, "The marks of the semester will be deleted for the student.", "Course Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (ok == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("delete from marks where student_id=? and semester=?");
                ps.setInt(1, id);
                ps.setInt(2, semester);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Marks Deleted Successfully");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Marks.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
