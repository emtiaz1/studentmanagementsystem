package student;

import database.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Course {

    Connection con = MyConnection.getConnection();
    PreparedStatement ps;

    public boolean getid(int id) {
        try {
            ps = con.prepareStatement("select * from student where id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Main_Menu.jTextField9.setText(String.valueOf(rs.getInt(1)));
                Main_Menu.jTextField10.setText(rs.getString(2));
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Student ID doesn't exist");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean isSemesterExist(int id, int semesterno) {
        try {
            ps = con.prepareStatement("select * from course where student_id=? and semester=?");
            ps.setInt(1, id);
            ps.setInt(2, semesterno);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean isCourseExist(int id, String courseno, String course) {
        try {
            ps = con.prepareStatement("select * from course where student_id=? and " + courseno + "=?");
            ps.setInt(1, id);
            ps.setString(2, course);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void insert(int id, String name, int semester, String course1, String course2) {
        String sql = "insert into course values(?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setInt(3, semester);
            ps.setString(4, course1);
            ps.setString(5, course2);
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student's Courses Added Successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void getCourseValue(JTable table, String searchValue) {
        String sql = "select * from course where concat(student_id,name,semester,course1,course2)like ? order by student_id asc, semester asc";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[5];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getInt(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                model.addRow(row);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void delete(int id, int semester) {
        int ok = JOptionPane.showConfirmDialog(null, "The courses of the semester will be deleted for the student.", "Course Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (ok == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("delete from course where student_id=? and semester=?");
                ps.setInt(1, id);
                ps.setInt(2, semester);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Courses Deleted Successfully");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
